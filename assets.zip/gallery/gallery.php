<?php
require_once __DIR__ . '/../admin/api/db.php';

$gallery = [];

try {
    $stmt = db()->query("
        SELECT * FROM gallery 
        WHERE active = 1 
        ORDER BY sort_order ASC, id DESC
    ");
    $gallery = $stmt->fetchAll();
} catch (Exception $e) {
    $gallery = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- ── PRIMARY SEO ── -->
  <title>Appliance Repair Gallery Nairobi | Before &amp; After Photos | VisionX Repairs</title>
  <link rel="icon" type="image/x-icon" href="../assets/images/web/p-logo-bg.png">
  <meta name="title" content="Appliance Repair Gallery Nairobi | Before &amp; After Photos | VisionX Repairs">
  <meta name="description" content="Real before &amp; after photos of fridge, washing machine and microwave repairs across Nairobi by VisionX Repairs. Samsung, LG, Bosch, Von Hotpoint and more. See our work.">
  <meta name="keywords" content="appliance repair photos Nairobi, fridge repair before after Nairobi, washing machine repair Nairobi photos, VisionX repairs gallery, Samsung fridge repair Nairobi photos, LG appliance repair Nairobi, repaired fridge Nairobi">
  <meta name="robots" content="index, follow">
  <meta name="geo.region" content="KE-110">
  <meta name="geo.placename" content="Nairobi, Kenya">
  <link rel="canonical" href="https://www.visionxrepairs.co.ke/gallery/">

  <!-- ── OPEN GRAPH ── -->
  <meta property="og:title" content="Appliance Repair Gallery Nairobi | VisionX Repairs">
  <meta property="og:description" content="Before &amp; after photos of appliance repairs across Nairobi by VisionX Repairs. Fridges, washing machines, microwaves.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://www.visionxrepairs.co.ke/gallery/">
  <meta property="og:image" content="https://www.visionxrepairs.co.ke/assets/images/main.png">
  <meta property="og:locale" content="en_KE">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="Appliance Repair Gallery Nairobi | VisionX Repairs">
  <meta name="twitter:description" content="Real before &amp; after repair photos from VisionX Repairs, Nairobi.">

  <!-- ── LOCAL BUSINESS SCHEMA ── -->
  <script type="application/ld+json">{
    "@context":"https://schema.org",
    "@type":"LocalBusiness",
    "name":"VisionX Appliance Repairs Nairobi",
    "description":"Expert fridge, washing machine and microwave repair across Nairobi. Before and after repair gallery.",
    "url":"https://www.visionxrepairs.co.ke",
    "telephone":"+254797340140",
    "email":"info@visionxrepairs.co.ke",
    "address":{"@type":"PostalAddress","addressLocality":"Nairobi","addressCountry":"KE"},
    "geo":{"@type":"GeoCoordinates","latitude":-1.286389,"longitude":36.817223},
    "openingHours":"Mo-Su 07:00-20:00",
    "priceRange":"KSh 1,500 - KSh 15,000",
    "aggregateRating":{"@type":"AggregateRating","ratingValue":"4.9","reviewCount":"89"}
  }</script>

  <!-- ── IMAGE GALLERY SCHEMA ── -->
  <script type="application/ld+json">{
    "@context":"https://schema.org",
    "@type":"ImageGallery",
    "name":"VisionX Appliance Repair Gallery – Nairobi Before & After Photos",
    "description":"Real photographs of appliance repairs completed by VisionX Repairs across Nairobi, Kenya. Fridge, washing machine, microwave, and freezer repairs.",
    "url":"https://www.visionxrepairs.co.ke/gallery/",
    "author":{"@type":"LocalBusiness","name":"VisionX Repairs","url":"https://www.visionxrepairs.co.ke"}
  }</script>

  <!-- ── BREADCRUMB SCHEMA ── -->
  <script type="application/ld+json">{
    "@context":"https://schema.org",
    "@type":"BreadcrumbList",
    "itemListElement":[
      {"@type":"ListItem","position":1,"name":"Home","item":"https://www.visionxrepairs.co.ke/"},
      {"@type":"ListItem","position":2,"name":"Repair Gallery","item":"https://www.visionxrepairs.co.ke/gallery/"}
    ]
  }</script>

  <!-- ── FAQ SCHEMA ── -->
  <script type="application/ld+json">{
    "@context":"https://schema.org",
    "@type":"FAQPage",
    "mainEntity":[
      {"@type":"Question","name":"Do you show photos of your appliance repairs in Nairobi?","acceptedAnswer":{"@type":"Answer","text":"Yes — VisionX shares real before and after photos of every major appliance repair completed across Nairobi, including fridge, washing machine, microwave and freezer repairs."}},
      {"@type":"Question","name":"Can I see proof of your fridge repair work in Nairobi?","acceptedAnswer":{"@type":"Answer","text":"Yes — our gallery shows completed fridge repair jobs across Nairobi suburbs including Westlands, Kilimani, Karen, Embakasi and more."}}
    ]
  }</script>

  <!-- ── ASSETS ── -->
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/styles.css">
</head>
<body>

<!-- ── ANNOUNCEMENT BAR ── -->
<div class="announce-bar">
  🔥 Same-Day Service Across Nairobi &nbsp;·&nbsp; Free Diagnosis &nbsp;·&nbsp;
  <a href="tel:+254797340140">Call Now: +254 797 340 140</a>
</div>

<!-- ── HEADER ── -->
<header class="site-header">
  <div class="header-inner">
    <a href="../../index.html" class="site-logo">
      <div class="logo-mark"><img src="../assets/images/web/p-logo-bg.png" alt="VisionX Logo" width="auto"></div>
      <span class="logo-text">Vision<span>X</span> Repairs</span>
    </a>
    <nav class="main-nav">
      <a href="../index.html">Home</a>
      <a href="../index.html#services">Services</a>
      <a href="../index.html#brands">Brands</a>
      <a href="../index.html#areas">Areas</a>
      <a href="../gallery/index.html" style="color:#fff;">Gallery</a>
      <a href="../index.html#faq">FAQ</a>
      <a href="tel:+254797340140" class="nav-call-btn"><i class="fas fa-phone"></i> Call Now</a>
    </nav>
    <button class="hamburger" id="nav-open" aria-label="Open menu">
      <span></span><span></span><span></span>
    </button>
  </div>
</header>

<!-- ── MOBILE NAV ── -->
<div class="nav-overlay" id="nav-overlay"></div>
<nav class="mobile-nav" id="mobile-nav">
  <div class="mobile-nav-head">
    <span>VisionX Repairs</span>
    <button class="close-btn" id="nav-close">&#x2715;</button>
  </div>
  <a href="../index.html"> Home</a>
  <a href="../index.html#services"> Services</a>
  <a href="../index.html#brands"> Brands</a>
  <a href="../index.html#areas"> Areas</a>
  <a href="../gallery/index.html"> Repair Gallery</a>
  <a href="../index.html#faq"> FAQ</a>
  <a href="../index.html#reviews"> Reviews</a>
  <a href="../service/emergency/index.html"> Emergency Repair</a>
  <a href="../service/commercial/index.html"> Commercial Repair</a>
  <div class="mobile-nav-footer">
    <a href="tel:+254797340140" class="mnf-call"><i class="fas fa-phone"></i> Call +254 797 340 140</a>
    <a href="https://api.whatsapp.com/send?phone=254797340140&text=Hello%21%20I%20need%20appliance%20repair%20in%20Nairobi." target="_blank" class="mnf-wa"><i class="fab fa-whatsapp"></i> WhatsApp</a>
  </div>
</nav>

<!-- ── TRUST BAR ── -->
<div class="trust-bar">
  <div class="trust-ticker">
    <div class="trust-ticker-item"><i class="fas fa-bolt"></i>Same-Day Service</div>
    <div class="trust-ticker-item"><i class="fas fa-shield-alt"></i>90-Day Warranty</div>
    <div class="trust-ticker-item"><i class="fas fa-search"></i>Free Diagnosis</div>
    <div class="trust-ticker-item"><i class="fas fa-clock"></i>24/7 Emergency</div>
    <div class="trust-ticker-item"><i class="fas fa-star"></i>4.9★ Rated</div>
    <div class="trust-ticker-item"><i class="fas fa-map-marker-alt"></i>All Nairobi Areas</div>
    <div class="trust-ticker-item"><i class="fas fa-tools"></i>All Major Brands</div>
    <div class="trust-ticker-item"><i class="fas fa-tags"></i>Transparent Pricing</div>
    <div class="trust-ticker-item"><i class="fas fa-bolt"></i>Same-Day Service</div>
    <div class="trust-ticker-item"><i class="fas fa-shield-alt"></i>90-Day Warranty</div>
    <div class="trust-ticker-item"><i class="fas fa-search"></i>Free Diagnosis</div>
    <div class="trust-ticker-item"><i class="fas fa-clock"></i>24/7 Emergency</div>
    <div class="trust-ticker-item"><i class="fas fa-star"></i>4.9★ Rated</div>
    <div class="trust-ticker-item"><i class="fas fa-map-marker-alt"></i>All Nairobi Areas</div>
    <div class="trust-ticker-item"><i class="fas fa-tools"></i>All Major Brands</div>
    <div class="trust-ticker-item"><i class="fas fa-tags"></i>Transparent Pricing</div>
  </div>
</div>

<!-- ── PAGE HERO ── -->
<section class="page-hero" aria-label="Appliance repair photo gallery Nairobi">
  <div class="page-hero-grid"></div>
  <div class="container">
    <!-- Breadcrumb -->
    <nav aria-label="Breadcrumb" style="margin-bottom:18px;">
      <ol style="list-style:none;display:flex;gap:8px;flex-wrap:wrap;font-size:13px;color:rgba(255,255,255,.5);">
        <li><a href="../index.html" style="color:rgba(255,255,255,.5);text-decoration:none;">Home</a></li>
        <li style="color:var(--orange);">/</li>
        <li style="color:rgba(255,255,255,.8);">Repair Gallery</li>
      </ol>
    </nav>
    <div class="hero-badge">
      <span><i class="fas fa-camera"></i> Before &amp; After Photos</span>
      <span><i class="fas fa-map-marker-alt"></i> Across Nairobi</span>
      <span><i class="fas fa-star"></i> Real Completed Jobs</span>
    </div>
    <h1>Appliance Repair <span class="span-orange">Gallery</span> – Nairobi</h1>
    <p>Real before &amp; after photos of fridge, washing machine, microwave and freezer repairs across Nairobi. Every job backed by our 90-day warranty.</p>
    <div class="btn-group">
      <a href="tel:+254797340140" class="btn-primary"><i class="fas fa-phone"></i> Book a Repair</a>
      <a href="https://api.whatsapp.com/send?phone=254797340140&text=Hello%21%20I%20saw%20your%20gallery%20and%20need%20a%20repair%20in%20Nairobi." target="_blank" class="btn-wa"><i class="fab fa-whatsapp"></i> WhatsApp</a>
    </div>
  </div>
</section>

<!-- ── MAIN GALLERY ── -->
<section class="section" id="gallery" aria-label="Before and after repair photos Nairobi">
  <div class="container">

    <!-- Stats row -->
    <div class="gallery-stats reveal">
      <div class="gs-item">
        <span class="gs-num" id="total-count">12</span>
        <span class="gs-label">Repairs Shown</span>
      </div>
      <div class="gs-item">
        <span class="gs-num">8+</span>
        <span class="gs-label">Nairobi Areas</span>
      </div>
      <div class="gs-item">
        <span class="gs-num">7</span>
        <span class="gs-label">Brands Covered</span>
      </div>
      <div class="gs-item">
        <span class="gs-num">4.9★</span>
        <span class="gs-label">Customer Rating</span>
      </div>
    </div>

    <!-- Filter buttons -->
    <div class="gallery-filters reveal" role="group" aria-label="Filter gallery by appliance type">
      <button class="gf-btn active" data-filter="all">All Repairs</button>
      <button class="gf-btn" data-filter="fridge">Fridge</button>
      <button class="gf-btn" data-filter="washing-machine">Washing Machine</button>
      <button class="gf-btn" data-filter="microwave">Microwave</button>
      <button class="gf-btn" data-filter="freezer">Freezer</button>
      <button class="gf-btn" data-filter="before">Before</button>
      <button class="gf-btn" data-filter="after">After</button>
    </div>

    <!-- Gallery grid -->
    <div class="gallery-grid" id="gallery-grid" role="list">

      <?php if (!empty($gallery)): ?>
        <?php foreach ($gallery as $item): ?>

          <article class="gallery-card reveal"
            data-type="<?php echo htmlspecialchars($item['appliance']); ?>"
            data-brand="<?php echo htmlspecialchars($item['brand']); ?>"
            data-area="<?php echo htmlspecialchars($item['area']); ?>"
            data-status="<?php echo htmlspecialchars($item['status']); ?>"
            data-title="<?php echo htmlspecialchars($item['title']); ?>"
            data-desc="<?php echo htmlspecialchars($item['description']); ?>"
            data-fault="<?php echo htmlspecialchars($item['fault']); ?>"
            role="listitem">

            <div class="gc-img-wrap">
              <img src="/visionx/<?php echo htmlspecialchars($item['img_path']); ?>"
                  alt="<?php echo htmlspecialchars($item['img_alt'] ?: $item['title']); ?>"
                  loading="lazy" width="400" height="300">

              <div class="gc-overlay">
                <div class="gc-overlay-icon"><i class="fas fa-expand"></i></div>
              </div>

              <span class="gc-status <?php echo $item['status'] === 'before' ? 'before' : 'after'; ?>">
                <?php echo $item['status'] === 'before' ? 'Before' : '✓ Fixed'; ?>
              </span>
            </div>

            <div class="gc-body">
              <div class="gc-meta">
                <span class="gc-tag">
                  <?php echo ucfirst(str_replace('-', ' ', $item['appliance'])); ?>
                </span>
                <span class="gc-area">
                  <i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($item['area']); ?>
                </span>
              </div>

              <h3><?php echo htmlspecialchars($item['title']); ?></h3>

              <p>
                <?php 
                echo htmlspecialchars(
                  strlen($item['description']) > 80 
                    ? substr($item['description'], 0, 80) . '...' 
                    : $item['description']
                ); 
                ?>
              </p>
            </div>

            <div class="gc-footer">
              <span class="gc-brand">
                <i class="fas fa-tag"></i> <?php echo htmlspecialchars($item['brand']); ?>
              </span>

              <a href="https://api.whatsapp.com/send?phone=254797340140&text=<?php 
                  echo urlencode('Hello! I need ' . $item['title'] . ' repair in ' . $item['area'] . ', Nairobi.'); 
              ?>"
                target="_blank"
                class="gc-wa-btn">
                <i class="fab fa-whatsapp"></i> Book Same Repair
              </a>
            </div>

          </article>

        <?php endforeach; ?>
      <?php else: ?>
        <p style="text-align:center;">No gallery items found.</p>
      <?php endif; ?>

      <!-- ══ CARD 12 – Upload Placeholder ══ -->
      <div class="gallery-upload-cta reveal" data-type="upload" role="listitem">
        <div class="up-icon"><i class="fas fa-camera"></i></div>
        <h4>More Photos Coming Soon</h4>
        <p>We add new before &amp; after repair photos regularly. Check back soon — or book your repair and see your appliance featured here!</p>
        <a href="https://api.whatsapp.com/send?phone=254797340140&text=Hello%21%20I%20need%20appliance%20repair%20in%20Nairobi." target="_blank" class="btn-wa" style="font-size:14px;padding:12px 22px;border-radius:8px;">
          <i class="fab fa-whatsapp"></i> Book a Repair Today
        </a>
      </div>

      <!-- Empty state shown when filter has no results -->
      <div class="gallery-empty" id="gallery-empty" style="display:none;">
        <div class="ge-icon">🔍</div>
        <p>No repairs found for this filter. <strong>Call us</strong> — we repair all brands and types across Nairobi.</p>
      </div>

    </div><!-- /gallery-grid -->

    <!-- ── HOW TO ADD YOUR PHOTOS (Admin note, hidden from users) ── -->
    <!--
    ═══════════════════════════════════════════════════════
    HOW TO ADD REAL PHOTOS TO THIS GALLERY
    ═══════════════════════════════════════════════════════
    1. Save your photo to:  assets/images/gallery/
       Recommended filename format:
         [brand]-[appliance]-[area]-[number].jpg
         e.g.  samsung-fridge-westlands-01.jpg
               lg-washer-kilimani-01.jpg

    2. Recommended photo size:  800×600px (4:3 ratio)
       Keep file size under 150KB for fast loading.
       Use tools like squoosh.app or tinyjpg.com to compress.

    3. In the gallery-card <article>, update the <img> tag:
         src="../assets/images/gallery/YOUR-FILENAME.jpg"
         alt="[Brand] [appliance] [fault] repair [area] Nairobi VisionX"
         ↑ IMPORTANT: descriptive alt text is critical for SEO

    4. Update data attributes on the <article> tag:
         data-type="fridge | washing-machine | microwave | freezer"
         data-brand="Samsung | LG | Bosch | ..."
         data-area="Westlands | Kilimani | ..."
         data-status="before | after | fixed"
         data-title="Short title for lightbox"
         data-desc="Full description for lightbox (1–3 sentences)"
         data-fault="Short fault summary"

    5. To add a NEW card: copy any existing <article class="gallery-card ...">
       block, paste it before the upload placeholder card, and update all fields.

    6. Update the gallery-stats count at the top if needed.
    ═══════════════════════════════════════════════════════
    -->

  </div>
</section>

<!-- ── SEO TEXT SECTION ── -->
<section class="section bg-off" aria-label="About VisionX appliance repair work Nairobi">
  <div class="container">
    <div style="max-width:800px;margin:0 auto;" class="reveal">
      <span class="label-tag">Our Work in Nairobi</span>
      <h2 style="margin-top:10px;">Real <span class="span-orange">Appliance Repairs</span> Across Nairobi</h2>
      <p style="margin-top:16px;">Every photo in this gallery represents a real appliance repair completed by VisionX Repairs across Nairobi — from fridge gas refills in Westlands to washing machine drum replacements in Kilimani. We document our work to give Nairobi customers confidence before booking.</p>
      <p style="margin-top:14px;">Our certified technicians repair <strong>fridges, washing machines, microwaves and freezers</strong> from all major brands including Samsung, LG, Bosch, Whirlpool, Von Hotpoint, Hisense and Ramtons. Every repair in Nairobi comes with a <strong>90-day parts and labour warranty</strong> and a free diagnosis before any charges.</p>
      <p style="margin-top:14px;">We serve all Nairobi areas including Westlands, Kilimani, Karen, Embakasi, Lavington, Parklands, Kasarani, Langata and more. <strong>Call before noon for same-day appliance repair in Nairobi.</strong></p>
      <div class="btn-group mt-24">
        <a href="tel:+254797340140" class="btn-primary"><i class="fas fa-phone"></i> Book a Repair</a>
        <a href="../index.html#pricing" class="btn-outline"><i class="fas fa-tags"></i> View Prices</a>
      </div>
    </div>
  </div>
</section>

<!-- ── FAQ ── -->
<section class="section" aria-label="Gallery FAQ appliance repair Nairobi">
  <div class="container">
    <div class="section-header center reveal">
      <span class="label-tag">Questions</span>
      <h2>About Our <span class="span-orange">Repair Gallery</span></h2>
    </div>
    <div class="faq-list" style="max-width:800px;margin:0 auto;">
      <div class="faq-item reveal">
        <div class="faq-question"><span>Are these real repair photos from Nairobi jobs?</span><span class="faq-icon">+</span></div>
        <div class="faq-answer">Yes — every image in this gallery is a real photo taken at an actual appliance repair job completed by VisionX technicians across Nairobi. We show both before and after photos where available.</div>
      </div>
      <div class="faq-item reveal">
        <div class="faq-question"><span>Can my repaired appliance be featured in the gallery?</span><span class="faq-icon">+</span></div>
        <div class="faq-answer">Yes! With your permission, we photograph interesting repairs and add them to this gallery. Just let your technician know during the repair visit.</div>
      </div>
      <div class="faq-item reveal">
        <div class="faq-question"><span>I have the same fault as one of these repairs — how do I book?</span><span class="faq-icon">+</span></div>
        <div class="faq-answer">Simply click the "Book Same Repair" WhatsApp button on any gallery card to send us a message about that specific fault — or call <a href="tel:+254797340140" style="color:var(--orange);">+254 797 340 140</a> and our team will arrange a technician visit.</div>
      </div>
      <div class="faq-item reveal">
        <div class="faq-question"><span>Do you offer before and after repair documentation?</span><span class="faq-icon">+</span></div>
        <div class="faq-answer">Yes — for all major repairs, our technicians document the fault before and the repaired state after. This is included in your repair report at no extra cost.</div>
      </div>
    </div>
  </div>
</section>

<!-- ── CTA ── -->
<section class="cta-section" aria-label="Book appliance repair Nairobi">
  <div class="container">
    <span class="label-tag" style="background:rgba(255,255,255,.15);color:#fff;">Book Today</span>
    <h2 style="color:#fff;margin-top:10px;">Your Appliance Could Be <span class="span-orange">Our Next Repair</span></h2>
    <p>Same-day service · Free diagnosis · 90-day warranty · All Nairobi areas</p>
    <div class="btn-group" style="justify-content:center;">
      <a href="tel:+254797340140" class="btn-white"><i class="fas fa-phone"></i> Call +254 797 340 140</a>
      <a href="https://api.whatsapp.com/send?phone=254797340140&text=Hello%21%20I%20need%20appliance%20repair%20in%20Nairobi." target="_blank" class="btn-wa"><i class="fab fa-whatsapp"></i> WhatsApp Now</a>
    </div>
  </div>
</section>

<!-- ── FOOTER ── -->
<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <div class="footer-logo">
          <div class="logo-mark">V</div>
          <span class="logo-text" style="color:#fff;">Vision<span style="color:var(--orange)">X</span></span>
        </div>
        <p class="footer-about">Nairobi's trusted appliance repair specialists. Fast, reliable, and affordable fridge, washing machine &amp; microwave repair across all Nairobi areas.</p>
        <div class="footer-social">
          <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
          <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
          <a href="https://www.youtube.com/@VisionXRepairs" aria-label="YouTube" target="_blank"><i class="fab fa-youtube"></i></a>
          <a href="https://api.whatsapp.com/send?phone=254797340140" aria-label="WhatsApp" target="_blank"><i class="fab fa-whatsapp"></i></a>
        </div>
      </div>
      <div class="footer-col">
        <h5>Services</h5>
        <a href="../index.html#services">Fridge Repair</a>
        <a href="../index.html#services">Washing Machine</a>
        <a href="../index.html#services">Microwave Repair</a>
        <a href="../service/freezer/index.html">Freezer Repair</a>
        <a href="../service/emergency/index.html">Emergency Repair</a>
        <a href="../service/commercial/index.html">Commercial Repair</a>
      </div>
      <div class="footer-col">
        <h5>Nairobi Areas</h5>
        <a href="../area/westlands/index.html">Westlands</a>
        <a href="../area/kilimani/index.html">Kilimani</a>
        <a href="../area/karen/index.html">Karen</a>
        <a href="../area/embakasi/index.html">Embakasi</a>
        <a href="../area/lavington/index.html">Lavington</a>
        <a href="../area/parklands/index.html">Parklands</a>
        <a href="../area/kasarani/index.html">Kasarani</a>
        <a href="../area/langata/index.html">Langata</a>
      </div>
      <div class="footer-col">
        <h5>Contact Us</h5>
        <div class="footer-contact-item"><i class="fas fa-map-marker-alt"></i><span>Nairobi, Kenya</span></div>
        <div class="footer-contact-item"><i class="fas fa-phone"></i><a href="tel:+254797340140">+254 797 340 140</a></div>
        <div class="footer-contact-item"><i class="fas fa-envelope"></i><a href="mailto:info@visionxrepairs.co.ke">info@visionxrepairs.co.ke</a></div>
        <div class="footer-contact-item"><i class="fas fa-clock"></i><span>Mon–Sun: 7am–8pm<br>24/7 Emergency Line</span></div>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <p>© 2025 VisionX Repairs – All Rights Reserved &nbsp;|&nbsp; Nairobi, Kenya &nbsp;|&nbsp;
    Designed by <a href="https://inoootechnologies.com/" target="_blank">Inooo Technologies</a></p>
  </div>
</footer>

<!-- ── LIGHTBOX ── -->
<div class="lightbox-overlay" id="lightbox" role="dialog" aria-modal="true" aria-label="Repair photo detail">
  <div class="lightbox-box">
    <button class="lightbox-close" id="lightbox-close" aria-label="Close">&#x2715;</button>
    <div class="lightbox-img-wrap">
      <img id="lb-img" src="" alt="">
    </div>
    <div class="lightbox-body">
      <div class="lightbox-meta" id="lb-meta"></div>
      <h2 id="lb-title"></h2>
      <p id="lb-fault" style="font-size:13px;color:var(--orange);font-weight:700;margin-bottom:10px;"></p>
      <p id="lb-desc"></p>
      <div class="lightbox-actions" id="lb-actions"></div>
    </div>
  </div>
</div>

<!-- ── FLOATING ACTIONS ── -->
<div class="fab-group">
  <a href="tel:+254797340140" class="fab-btn fab-call"><i class="fas fa-phone"></i><span>Call Now</span></a>
  <a href="https://api.whatsapp.com/send?phone=254797340140&text=Hello%21%20I%20need%20appliance%20repair%20in%20Nairobi." target="_blank" class="fab-btn fab-wa"><i class="fab fa-whatsapp"></i><span>WhatsApp</span></a>
</div>
<div class="bottom-bar">
  <a href="tel:+254797340140" class="bb-call"><i class="fas fa-phone"></i> Call Now</a>
  <a href="https://api.whatsapp.com/send?phone=254797340140&text=Hello%21%20I%20need%20appliance%20repair%20in%20Nairobi." target="_blank" class="bb-wa"><i class="fab fa-whatsapp"></i> WhatsApp</a>
</div>

<script>
// ── Mobile Nav ──
(function(){
  var openBtn  = document.getElementById('nav-open');
  var closeBtn = document.getElementById('nav-close');
  var nav      = document.getElementById('mobile-nav');
  var overlay  = document.getElementById('nav-overlay');
  function openNav()  { nav.classList.add('open'); overlay.classList.add('open'); document.body.style.overflow='hidden'; }
  function closeNav() { nav.classList.remove('open'); overlay.classList.remove('open'); document.body.style.overflow=''; }
  if(openBtn)  openBtn.addEventListener('click', openNav);
  if(closeBtn) closeBtn.addEventListener('click', closeNav);
  if(overlay)  overlay.addEventListener('click', closeNav);
  document.querySelectorAll('#mobile-nav a').forEach(function(a){ a.addEventListener('click', closeNav); });
  var hdr = document.querySelector('.site-header');
  window.addEventListener('scroll', function(){
    if(hdr) hdr.style.boxShadow = window.scrollY > 10 ? '0 4px 32px rgba(0,0,0,.35)' : '';
  }, {passive:true});
})();

// ── FAQ ──
document.querySelectorAll('.faq-question').forEach(function(q){
  q.addEventListener('click', function(){
    var a = this.nextElementSibling;
    var isOpen = a.classList.contains('open');
    document.querySelectorAll('.faq-answer').forEach(function(x){ x.classList.remove('open'); });
    document.querySelectorAll('.faq-question').forEach(function(x){ x.classList.remove('active'); });
    if(!isOpen){ a.classList.add('open'); this.classList.add('active'); }
  });
});

// ── Scroll Reveal ──
var revealObs = new IntersectionObserver(function(entries){
  entries.forEach(function(e){ if(e.isIntersecting) e.target.classList.add('visible'); });
}, {threshold:0.1});
document.querySelectorAll('.reveal').forEach(function(el){ revealObs.observe(el); });

// ── Gallery Filter ──
var filterBtns  = document.querySelectorAll('.gf-btn');
var galleryCards = document.querySelectorAll('#gallery-grid .gallery-card');
var emptyState  = document.getElementById('gallery-empty');
var totalCount  = document.getElementById('total-count');

function applyFilter(filter) {
  var visible = 0;
  galleryCards.forEach(function(card) {
    var t = card.getAttribute('data-type');
    var s = card.getAttribute('data-status');
    var show = (filter === 'all') ||
               (filter === t) ||
               (filter === s);
    card.style.display = show ? '' : 'none';
    if(show) visible++;
  });
  if(totalCount) totalCount.textContent = visible;
  if(emptyState) emptyState.style.display = visible === 0 ? 'block' : 'none';
}

filterBtns.forEach(function(btn) {
  btn.addEventListener('click', function() {
    filterBtns.forEach(function(b){ b.classList.remove('active'); });
    this.classList.add('active');
    applyFilter(this.getAttribute('data-filter'));
  });
});

// ── Lightbox ──
var lightbox   = document.getElementById('lightbox');
var lbClose    = document.getElementById('lightbox-close');
var lbImg      = document.getElementById('lb-img');
var lbTitle    = document.getElementById('lb-title');
var lbDesc     = document.getElementById('lb-desc');
var lbFault    = document.getElementById('lb-fault');
var lbMeta     = document.getElementById('lb-meta');
var lbActions  = document.getElementById('lb-actions');

function openLightbox(card) {
  var imgEl   = card.querySelector('.gc-img-wrap img');
  var title   = card.getAttribute('data-title')   || '';
  var desc    = card.getAttribute('data-desc')    || '';
  var fault   = card.getAttribute('data-fault')   || '';
  var brand   = card.getAttribute('data-brand')   || '';
  var area    = card.getAttribute('data-area')    || '';
  var status  = card.getAttribute('data-status')  || '';
  var waLink  = card.querySelector('.gc-wa-btn') ? card.querySelector('.gc-wa-btn').href : '#';

  if(imgEl && imgEl.src) {
    lbImg.src = imgEl.src;
    lbImg.alt = imgEl.alt || title;
  }

  lbTitle.textContent  = title;
  lbDesc.textContent   = desc;
  lbFault.textContent  = fault ? '🔧 ' + fault : '';

  var statusClass = status === 'before' ? 'before' : 'after';
  var statusLabel = status === 'before' ? 'Before Repair' : '✓ Fixed';
  lbMeta.innerHTML =
    '<span class="gc-status ' + statusClass + '" style="position:static;">' + statusLabel + '</span>' +
    '<span class="gc-tag">' + brand + '</span>' +
    '<span class="gc-area"><i class="fas fa-map-marker-alt"></i> ' + area + ', Nairobi</span>';

  lbActions.innerHTML =
    '<a href="tel:+254797340140" class="btn-primary" style="font-size:14px;padding:11px 20px;"><i class="fas fa-phone"></i> Call Now</a>' +
    '<a href="' + waLink + '" target="_blank" class="btn-wa" style="font-size:14px;padding:11px 20px;"><i class="fab fa-whatsapp"></i> Book This Repair</a>';

  lightbox.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeLightbox() {
  lightbox.classList.remove('open');
  document.body.style.overflow = '';
}

galleryCards.forEach(function(card) {
  card.addEventListener('click', function(e) {
    if(e.target.closest('.gc-wa-btn')) return; // let WhatsApp link work
    openLightbox(card);
  });
  card.addEventListener('keydown', function(e) {
    if(e.key === 'Enter' || e.key === ' ') openLightbox(card);
  });
  card.setAttribute('tabindex', '0');
  card.setAttribute('role', 'button');
});

if(lbClose)  lbClose.addEventListener('click', closeLightbox);
lightbox.addEventListener('click', function(e) {
  if(e.target === lightbox) closeLightbox();
});
document.addEventListener('keydown', function(e) {
  if(e.key === 'Escape') closeLightbox();
});

function areaWA(area) {
  var msg = 'Hello! I need appliance repair in ' + area + ', Nairobi. Please assist.';
  window.open('https://api.whatsapp.com/send?phone=254797340140&text=' + encodeURIComponent(msg), '_blank');
}
</script>
</body>
</html>